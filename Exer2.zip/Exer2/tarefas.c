#include <stdio.h>
#include <stdlib.h>
#include "tarefas.h"

struct data
{
    int dia;
    int mes;
    int ano;
};

struct tarefa
{
    char id [100];
    int prioridade;
    Data date;
    struct tarefa *anterior;
    struct tarefa *proximo;
};

//.......................................................................................................

//cria uma lista de tarefas 
Tarefa *criarLista()
{
    return NULL;
}

//Inserir Tarefas
Tarefa* inserirTarefa(Tarefa* l, char id[50], int prioridade, int dia, int mes, int ano)
{

    Tarefa* novaTarefa = (Tarefa*)malloc(sizeof(Tarefa));
    Data *novaData = (Data*)malloc(sizeof(Data));

    if(novaTarefa == NULL || novaData == NULL)
    {
        printf("A tarefa nao foi inserida!!!!");
        return NULL;
    }
    novaData->dia = dia;
    novaData->mes = mes;
    novaData->ano = ano;

    novaTarefa->date = *novaData;
    novaTarefa->prioridade = prioridade;
    strcpy(novaTarefa->id, id);

    // Lista vazia
    if (l == NULL) 
    {
        novaTarefa->anterior = NULL;
        novaTarefa->proximo = NULL;
        return novaTarefa;
    }

    // Lista com elementos
    novaTarefa->proximo = l;
    novaTarefa->anterior = NULL;
    l->anterior = novaTarefa;

    return novaTarefa;
}

//Listar tarefas
void listarTarefas(Tarefa *tarefas) 
{
    Tarefa *atual = tarefas;

    printf("Listagem ordenada por prioridade:\n");

    int numTarefas = 0;

    // Loop para percorrer todas as prioridades, de 5 a 0
    for (int prioridade = 5; prioridade >= 0; prioridade--) {

        // Loop para percorrer as tarefas e imprimir aquelas com a prioridade atual
        while (atual != NULL) {
            if (atual->prioridade == prioridade) {
                printf("ID: %s, Prioridade: %d, Data: %d/%d/%d\n", atual->id,
                       atual->prioridade, atual->date.dia,
                       atual->date.mes, atual->date.ano);
                numTarefas++;
            }
            atual = atual->proximo;
        }
        // Reinicia a lista para o próximo loop de prioridade
        atual = tarefas;
    }

    // Verifica se nenhuma tarefa foi listada
    if (numTarefas == 0) {
        printf("Nenhuma tarefa encontrada.\n");
    }
}



Tarefa *complete(char id[100] , Tarefa *tarefas)
{
    Tarefa *tarefa = tarefas;

    if (tarefa == NULL)
    {
        printf("Lista Vazia!!!");
        return NULL;
    }
    else
    {
        while (tarefa != NULL && strcmp(tarefa->id, id) != 0)
        {
            tarefa = tarefa->proximo;
        }
    }

    
    if (tarefa != NULL)
    {
        
        if (tarefa->anterior != NULL)
        {
            tarefa->anterior->proximo = tarefa->proximo;
        }

        if (tarefa->proximo != NULL)
        {
            tarefa->proximo->anterior = tarefa->anterior;
        }

        Tarefa *t = tarefa->proximo;
        free(tarefa);

        printf("Tarefa removida!!!!!!!!");

        return t;
    }
    else
    {
        printf("TAREFA INEXISTENTE");
        return tarefa;
    }

}


