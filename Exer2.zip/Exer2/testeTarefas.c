#include <stdio.h>
#include <stdlib.h>
#include "tarefa.c"

int main()
{
    char id[100];
    int prioridade;
    int dia;
    int mes ;
    int ano;
    int opcao;

    Tarefa *tarefa = criarLista();

        do{
        printf("1- Inserir Tarefa\n2- Listar Tarefas\n3-Retirar Tarefa\n4- Sair");
        scanf(" %d",&opcao);
        switch(opcao)
        {
            case 1:
                printf("1- Inserir Tarefa: ");
                printf("Digite o id");
                scanf(" ");
                fgets(id, sizeof(id), stdin);
                printf("Digite a prioridade: ");
                scanf(" %d",&prioridade);
                printf("Digite a data\n");
                printf("dia\n");
                scanf(" %d",&dia);
                printf("mes\n");
                scanf(" %d",&mes);
                printf("ano\n ");
                scanf(" %d",&ano);
                tarefa = inserirTarefa(tarefa,id,prioridade,dia,mes,ano);
            break;
            case 2:
                printf("Listar Tarefas: ");
                listarTarefas(tarefa);
                break;
            case 3:
                printf("Retirar Tarefa: ");
                printf("Digite o ID: ");
                scanf(" ");
                fgets(id, sizeof(id), stdin);
                complete(id,tarefa);
                break;
            case 4:
                printf("Abortar Programa por escolha do utilizador!!!");
                break;
            default:
                printf("Opcao Invalida. Tente Novamente!!!!");
        }

    }while(opcao != 4);

        return 0;
    }


