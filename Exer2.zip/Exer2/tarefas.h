typedef struct tarefa Tarefa;
typedef struct data Data;

Tarefa* inserirTarefa(Tarefa* l, char id[50], int prioridade, int dia, int mes, int ano);
Tarefa *complete(char id[100] , Tarefa *tarefas);
void listarTarefas(Tarefa *tarefas);